/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[44];
    char stringdata0[418];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(33, 0), // ""
QT_MOC_LITERAL(34, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(58, 18), // "on_new_btn_clicked"
QT_MOC_LITERAL(77, 23), // "on_textEdit_textChanged"
QT_MOC_LITERAL(101, 33), // "on_textEdit_cursorPositionCha..."
QT_MOC_LITERAL(135, 17), // "onFoundBtnClicked"
QT_MOC_LITERAL(153, 11), // "std::string"
QT_MOC_LITERAL(165, 18), // "on_found_1_clicked"
QT_MOC_LITERAL(184, 18), // "on_found_2_clicked"
QT_MOC_LITERAL(203, 18), // "on_found_3_clicked"
QT_MOC_LITERAL(222, 18), // "on_copyBtn_clicked"
QT_MOC_LITERAL(241, 17), // "on_cutBtn_clicked"
QT_MOC_LITERAL(259, 19), // "on_pasteBtn_clicked"
QT_MOC_LITERAL(279, 28), // "on_textEdit_selectionChanged"
QT_MOC_LITERAL(308, 11), // "autoCorrect"
QT_MOC_LITERAL(320, 10), // "revertBack"
QT_MOC_LITERAL(331, 18), // "on_undoBtn_clicked"
QT_MOC_LITERAL(350, 18), // "on_redoBtn_clicked"
QT_MOC_LITERAL(369, 22), // "on_findreplace_clicked"
QT_MOC_LITERAL(392, 25) // "on_findreplaceall_clicked"

    },
    "MainWindow\0on_pushButton_clicked\0\0"
    "on_pushButton_2_clicked\0on_new_btn_clicked\0"
    "on_textEdit_textChanged\0"
    "on_textEdit_cursorPositionChanged\0"
    "onFoundBtnClicked\0std::string\0"
    "on_found_1_clicked\0on_found_2_clicked\0"
    "on_found_3_clicked\0on_copyBtn_clicked\0"
    "on_cutBtn_clicked\0on_pasteBtn_clicked\0"
    "on_textEdit_selectionChanged\0autoCorrect\0"
    "revertBack\0on_undoBtn_clicked\0"
    "on_redoBtn_clicked\0on_findreplace_clicked\0"
    "on_findreplaceall_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  128,    2, 0x08,    1 /* Private */,
       3,    0,  129,    2, 0x08,    2 /* Private */,
       4,    0,  130,    2, 0x08,    3 /* Private */,
       5,    0,  131,    2, 0x08,    4 /* Private */,
       6,    0,  132,    2, 0x08,    5 /* Private */,
       7,    1,  133,    2, 0x08,    6 /* Private */,
       9,    0,  136,    2, 0x08,    8 /* Private */,
      10,    0,  137,    2, 0x08,    9 /* Private */,
      11,    0,  138,    2, 0x08,   10 /* Private */,
      12,    0,  139,    2, 0x08,   11 /* Private */,
      13,    0,  140,    2, 0x08,   12 /* Private */,
      14,    0,  141,    2, 0x08,   13 /* Private */,
      15,    0,  142,    2, 0x08,   14 /* Private */,
      16,    1,  143,    2, 0x08,   15 /* Private */,
      17,    0,  146,    2, 0x08,   17 /* Private */,
      18,    0,  147,    2, 0x08,   18 /* Private */,
      19,    0,  148,    2, 0x08,   19 /* Private */,
      20,    0,  149,    2, 0x08,   20 /* Private */,
      21,    0,  150,    2, 0x08,   21 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: _t->on_pushButton_2_clicked(); break;
        case 2: _t->on_new_btn_clicked(); break;
        case 3: _t->on_textEdit_textChanged(); break;
//        case 4: _t->on_textEdit_cursorPositionChanged(); break;
        case 5: _t->onFoundBtnClicked((*reinterpret_cast< std::add_pointer_t<std::string>>(_a[1]))); break;
        case 6: _t->on_found_1_clicked(); break;
        case 7: _t->on_found_2_clicked(); break;
        case 8: _t->on_found_3_clicked(); break;
        case 9: _t->on_copyBtn_clicked(); break;
        case 10: _t->on_cutBtn_clicked(); break;
        case 11: _t->on_pasteBtn_clicked(); break;
//        case 12: _t->on_textEdit_selectionChanged(); break;
        case 13: _t->autoCorrect((*reinterpret_cast< std::add_pointer_t<std::string>>(_a[1]))); break;
        case 14: _t->revertBack(); break;
        case 15: _t->on_undoBtn_clicked(); break;
        case 16: _t->on_redoBtn_clicked(); break;
        case 17: _t->on_findreplace_clicked(); break;
        case 18: _t->on_findreplaceall_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<std::string, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
